COURTSIDE NBA WEBSITE — QUICK START

1. Open index.html in a browser to preview the website.
2. To publish free with Netlify:
   - Visit https://app.netlify.com/drop
   - Sign in or create an account.
   - Drag the entire courtside_site folder (or upload its contents) into the drop area.
   - Netlify will create a public website URL.
3. To make updates, edit index.html and redeploy the folder.

This is a front-end prototype. Career progress is saved in the visitor's browser.
It does not yet have accounts, cloud saves, live NBA scores/news, multiplayer, or a database.
The NBA team directory is included; simulated career events are fictional.
